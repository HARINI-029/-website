AptiQuest - Static Prototype

This is a client-side static website (no server required) implementing:
- 20 chapters × 600 questions each (tick to mark as solved)
- Points per question, daily bonus, streaks
- Export / Import JSON for moving progress between devices

How to use:
1. Download and unzip the files.
2. Open index.html in a browser (Chrome/Edge/Firefox). For best experience, run via a local server (python -m http.server).
3. Create a username and start ticking questions. Use Export to save progress, Import to load on another device.

Notes:
- The site stores data in browser localStorage under key 'AptiQuest:user:<username>'.
- This prototype is static; to host publicly, upload these files to GitHub Pages or any static host.

Generated on 2025-10-06T09:47:43.350894 UTC

// AptiQuest - static client-side prototype
(function(){
  const NUM_CHAPTERS = 20;
  const QUESTIONS_PER_CHAPTER = 600;
  const POINTS_PER_QUESTION = 10;
  const BONUS_DAILY = 5;

  // DOM
  const usernameInput = document.getElementById('username');
  const btnLogin = document.getElementById('btnLogin');
  const btnDemo = document.getElementById('btnDemo');
  const btnExport = document.getElementById('btnExport');
  const btnImport = document.getElementById('btnImport');
  const fileInput = document.getElementById('fileInput');
  const btnLogout = document.getElementById('btnLogout');

  const dashboard = document.getElementById('dashboard');
  const chaptersGrid = document.getElementById('chapters');
  const pointsEl = document.getElementById('points');
  const streakEl = document.getElementById('streak');
  const totalSolvedEl = document.getElementById('totalSolved');
  const dailySetBtn = document.getElementById('dailySet');

  const chapterView = document.getElementById('chapterView');
  const chapterTitle = document.getElementById('chapterTitle');
  const questionsContainer = document.getElementById('questions');
  const backBtn = document.getElementById('backBtn');
  const markAllBtn = document.getElementById('markAll');
  const clearAllBtn = document.getElementById('clearAll');
  const chapterSolvedEl = document.getElementById('chapterSolved');
  const questionsPerChapterEl = document.getElementById('questionsPerChapter');

  let state = {username:'', chapters:[], points:0, lastActive:null, streak:0, createdAt: null};

  // utilities
  function nowDateStr(){ return new Date().toISOString().slice(0,10); }
  function emptyChapters(){ return Array.from({length:NUM_CHAPTERS}, ()=> Array.from({length:QUESTIONS_PER_CHAPTER}, ()=>0)); }
  function storageKey(u){ return 'AptiQuest:user:'+u; }

  function saveState(){ if(!state.username) return; localStorage.setItem(storageKey(state.username), JSON.stringify(state)); }
  function loadState(u){ const raw = localStorage.getItem(storageKey(u)); return raw ? JSON.parse(raw) : null; }

  function calcTotals(){ const totals = state.chapters.map(c=> c.reduce((s,v)=>s+v,0)); const totalSolved = totals.reduce((s,v)=>s+v,0); return {totals, totalSolved}; }

  function renderDashboard(){
    const {totals, totalSolved} = calcTotals();
    pointsEl.textContent = state.points||0;
    streakEl.textContent = state.streak||0;
    totalSolvedEl.textContent = totalSolved;
    chaptersGrid.innerHTML = '';
    for(let i=0;i<NUM_CHAPTERS;i++){
      const solved = totals[i];
      const div = document.createElement('div');
      div.className = 'chapter-card';
      div.innerHTML = `<h3>Chapter ${i+1}</h3><div class="small">Solved: ${solved}/${QUESTIONS_PER_CHAPTER}</div><div class="progress"><i style="width:${(solved/QUESTIONS_PER_CHAPTER)*100}%"></i></div><div style="text-align:right;margin-top:8px"><button data-ch="${i}" class="openBtn">Open</button></div>`;
      chaptersGrid.appendChild(div);
    }
    dashboard.style.display = 'block';
    chapterView.style.display = 'none';
    document.querySelectorAll('.openBtn').forEach(b=> b.addEventListener('click', ()=>{ openChapter(Number(b.dataset.ch)); }));
  }

  function openChapter(idx){
    chapterTitle.textContent = 'Chapter '+(idx+1);
    chapterView.dataset.chapter = idx;
    const arr = state.chapters[idx];
    chapterSolvedEl.textContent = arr.reduce((s,v)=>s+v,0);
    questionsPerChapterEl.textContent = QUESTIONS_PER_CHAPTER;
    questionsContainer.innerHTML = ''; // render 600 checkboxes
    // render in pages of 50 for performance? we'll render all but it's scrollable.
    for(let i=0;i<QUESTIONS_PER_CHAPTER;i++){
      const q = document.createElement('label');
      q.className = 'question';
      q.innerHTML = `<span>Q${i+1}</span><input type="checkbox" data-q="${i}" ${arr[i]? 'checked':''}>`;
      questionsContainer.appendChild(q);
    }
    // attach listeners
    questionsContainer.querySelectorAll('input[type=checkbox]').forEach(chk=>{
      chk.addEventListener('change', (e)=>{
        const qi = Number(e.target.dataset.q);
        toggleQuestion(idx, qi);
      });
    });
    dashboard.style.display = 'none';
    chapterView.style.display = 'block';
    window.scrollTo({top:0, behavior:'smooth'});
  }

  function toggleQuestion(chIndex, qIndex){
    const was = state.chapters[chIndex][qIndex];
    state.chapters[chIndex][qIndex] = was ? 0 : 1;
    state.points = (state.points||0) + (was ? -POINTS_PER_QUESTION : POINTS_PER_QUESTION);
    // update daily bonus/streak if first activity of day
    const today = nowDateStr();
    if(state.lastActive !== today){
      const yesterday = new Date(Date.now()-86400000).toISOString().slice(0,10);
      if(state.lastActive === yesterday) state.streak = (state.streak||0)+1; else state.streak = 1;
      state.lastActive = today;
      state.points = (state.points||0) + BONUS_DAILY;
    }
    saveState();
    const arr = state.chapters[chIndex];
    chapterSolvedEl.textContent = arr.reduce((s,v)=>s+v,0);
    const totals = calcTotals();
    totalSolvedEl.textContent = totals.totalSolved;
    pointsEl.textContent = state.points;
  }

  function markAll(chIndex){
    const arr = state.chapters[chIndex];
    let added = 0;
    for(let i=0;i<arr.length;i++) if(!arr[i]){ arr[i]=1; added++; }
    state.points = (state.points||0) + added*POINTS_PER_QUESTION;
    saveState();
  }

  function clearAll(chIndex){
    if(!confirm('Clear all marks in this chapter?')) return;
    const arr = state.chapters[chIndex];
    let removed = 0;
    for(let i=0;i<arr.length;i++) if(arr[i]){ arr[i]=0; removed++; }
    state.points = Math.max(0, (state.points||0) - removed*POINTS_PER_QUESTION);
    saveState();
  }

  // auth handlers
  btnLogin.addEventListener('click', ()=>{
    const u = usernameInput.value && usernameInput.value.trim();
    if(!u) return alert('Enter a username');
    let loaded = loadState(u);
    if(!loaded){
      loaded = {username:u, chapters:emptyChapters(), points:0, lastActive:null, streak:0, createdAt:new Date().toISOString()};
      localStorage.setItem(storageKey(u), JSON.stringify(loaded));
    }
    state = loaded;
    usernameInput.disabled = true;
    btnLogout.style.display = 'inline-block';
    btnLogin.style.display = 'none';
    btnDemo.style.display = 'none';
    renderDashboard();
  });

  btnDemo.addEventListener('click', ()=>{
    const demo = {username:'demo', chapters:emptyChapters(), points:10, lastActive: nowDateStr(), streak:1, createdAt: new Date().toISOString()};
    demo.chapters[0][0]=1;
    localStorage.setItem(storageKey('demo'), JSON.stringify(demo));
    usernameInput.value = 'demo';
    usernameInput.disabled = true;
    state = demo;
    btnLogout.style.display = 'inline-block';
    btnLogin.style.display = 'none';
    btnDemo.style.display = 'none';
    renderDashboard();
  });

  btnLogout.addEventListener('click', ()=>{
    state = {username:'', chapters:[], points:0, lastActive:null, streak:0, createdAt:null};
    usernameInput.disabled = false;
    usernameInput.value = '';
    btnLogout.style.display = 'none';
    btnLogin.style.display = 'inline-block';
    btnDemo.style.display = 'inline-block';
    dashboard.style.display = 'none';
    chapterView.style.display = 'none';
  });

  backBtn.addEventListener('click', ()=>{ renderDashboard(); });

  markAllBtn.addEventListener('click', ()=>{ const ch = Number(chapterView.dataset.chapter); markAll(ch); openChapter(ch); });
  clearAllBtn.addEventListener('click', ()=>{ const ch = Number(chapterView.dataset.chapter); clearAll(ch); openChapter(ch); });

  dailySetBtn.addEventListener('click', ()=>{
    // mark 5 random questions
    const ch = Math.floor(Math.random()*NUM_CHAPTERS);
    let added = 0;
    for(let i=0;i<5;i++){
      const q = Math.floor(Math.random()*QUESTIONS_PER_CHAPTER);
      if(!state.chapters[ch][q]){ state.chapters[ch][q]=1; added++; }
    }
    state.points = (state.points||0) + added*POINTS_PER_QUESTION + BONUS_DAILY;
    state.lastActive = nowDateStr();
    state.streak = (state.streak||0) + 1;
    saveState();
    renderDashboard();
  });

  // export/import
  btnExport.addEventListener('click', ()=>{
    if(!state.username) return alert('Login first');
    const dataStr = JSON.stringify(state);
    const blob = new Blob([dataStr], {type:'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = `${state.username}-aptiqueast.json`; a.click();
  });

  btnImport.addEventListener('click', ()=>{ fileInput.click(); });
  fileInput.addEventListener('change', (e)=>{
    const f = e.target.files[0];
    if(!f) return;
    const r = new FileReader();
    r.onload = (ev)=>{
      try{
        const parsed = JSON.parse(ev.target.result);
        if(!parsed.username || !parsed.chapters) return alert('Invalid file');
        localStorage.setItem(storageKey(parsed.username), JSON.stringify(parsed));
        state = parsed;
        usernameInput.value = parsed.username;
        usernameInput.disabled = true;
        btnLogout.style.display = 'inline-block';
        btnLogin.style.display = 'none';
        btnDemo.style.display = 'none';
        renderDashboard();
      }catch(err){ alert('Import failed: '+err.message); }
    };
    r.readAsText(f);
  });

  // init
  renderDashboard();
})();